# marketing-materials

Publicly available marketing materials for Fontlab Ltd. apps. 

## Download

### [Download ZIP](https://github.com/Fontlab/marketing-materials/raw/main/download/fontlab-marketing-materials.zip) (22 MB)

The above ZIP contains the Fontlab Ltd. logo (in the `company` folder), as well as app icons, screenshots and graphics for FontLab 8 and for TransType 4. 

---

Copyright (c) 2013-2023 by Fontlab Ltd. Licensed to authorized users only. 

